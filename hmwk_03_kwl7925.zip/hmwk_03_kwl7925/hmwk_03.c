// Loyd, Kanyon W.
// kwl7925
// 2019-10-04

#include <stdio.h>

int main( int argc, char *argv[] )
{
  printf("Hello, world!\n");
}
