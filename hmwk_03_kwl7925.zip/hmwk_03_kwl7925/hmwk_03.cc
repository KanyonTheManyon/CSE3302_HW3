// Loyd, Kanyon W.
// kwl7925
// 2019-10-04

#include <iostream>

using namespace std;

int main( int argc, char *argv[] )
{
  cout << "Hello, world!" << endl;
}
